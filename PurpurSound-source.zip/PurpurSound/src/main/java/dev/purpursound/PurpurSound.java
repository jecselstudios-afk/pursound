package dev.purpursound;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.SoundCategory;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class PurpurSound extends JavaPlugin implements TabExecutor, Listener {

    private static final String NS = "purpursound";
    private static final UUID PACK_ID = UUID.nameUUIDFromBytes("purpursound-pack".getBytes(StandardCharsets.UTF_8));

    private Path soundsDir;
    private volatile byte[] packBytes = new byte[0];
    private volatile String packHash = "";
    private HttpServer http;
    private final Map<String, Long> tokens = new ConcurrentHashMap<>();   // token -> expiry millis
    private final Map<String, String> tokenNames = new ConcurrentHashMap<>(); // token -> preset name
    private final Set<UUID> scared = ConcurrentHashMap.newKeySet();
    private final SecureRandom random = new SecureRandom();
    private String currentSong = null;
    private NamespacedKey helmetKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        helmetKey = new NamespacedKey(this, "jumpscare_helmet");
        soundsDir = getDataFolder().toPath().resolve("sounds");
        try { Files.createDirectories(soundsDir); } catch (IOException e) { throw new RuntimeException(e); }
        rebuildPack();
        startWebServer();

        for (String c : List.of("addsound", "playsong", "stopsong", "songs", "jumpscare")) {
            Objects.requireNonNull(getCommand(c)).setExecutor(this);
        }
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        if (http != null) http.stop(0);
        for (Player p : Bukkit.getOnlinePlayers()) if (scared.contains(p.getUniqueId())) restoreHelmet(p);
    }

    // ------------------------------------------------------------------ Resource pack

    private synchronized void rebuildPack() {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            List<String> names = new ArrayList<>(listSongs());
            try (ZipOutputStream zip = new ZipOutputStream(bos)) {
                put(zip, "pack.mcmeta", ("{\"pack\":{\"description\":\"PurpurSound\",\"min_format\":"
                        + getConfig().getInt("pack-min-format", 65) + ",\"max_format\":"
                        + getConfig().getInt("pack-max-format", 999) + "}}").getBytes(StandardCharsets.UTF_8));
                StringBuilder json = new StringBuilder("{");
                for (int i = 0; i < names.size(); i++) {
                    String n = names.get(i);
                    if (i > 0) json.append(',');
                    json.append('"').append(n).append("\":{\"sounds\":[{\"name\":\"").append(NS).append(':').append(n)
                            .append("\",\"stream\":true}]}");
                    put(zip, "assets/" + NS + "/sounds/" + n + ".ogg", Files.readAllBytes(soundsDir.resolve(n + ".ogg")));
                }
                json.append('}');
                put(zip, "assets/" + NS + "/sounds.json", json.toString().getBytes(StandardCharsets.UTF_8));
            }
            packBytes = bos.toByteArray();
            StringBuilder hex = new StringBuilder();
            for (byte b : MessageDigest.getInstance("SHA-1").digest(packBytes)) hex.append(String.format("%02x", b));
            packHash = hex.toString();
        } catch (Exception e) {
            getLogger().severe("Failed to build resource pack: " + e);
        }
    }

    private void put(ZipOutputStream zip, String name, byte[] data) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setTime(0); // deterministic hash
        zip.putNextEntry(e);
        zip.write(data);
        zip.closeEntry();
    }

    private List<String> listSongs() {
        try (Stream<Path> s = Files.list(soundsDir)) {
            return s.map(p -> p.getFileName().toString()).filter(f -> f.endsWith(".ogg"))
                    .map(f -> f.substring(0, f.length() - 4)).sorted().toList();
        } catch (IOException e) { return List.of(); }
    }

    private void sendPack(Player p) {
        String url = "http://" + getConfig().getString("public-host") + ":" + getConfig().getInt("public-port")
                + "/pack.zip?h=" + packHash;
        p.setResourcePack(PACK_ID, url, packHash, Component.text("Server sounds & jumpscares"), false);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        byte[] saved = p.getPersistentDataContainer().get(helmetKey, PersistentDataType.BYTE_ARRAY);
        if (saved != null) restoreHelmet(p); // crash safety
        if (!listSongs().isEmpty()) sendPack(p);
    }

    // ------------------------------------------------------------------ Web server (upload + pack hosting)

    private void startWebServer() {
        try {
            http = HttpServer.create(new InetSocketAddress(getConfig().getInt("web-port", 8123)), 0);
            http.createContext("/pack.zip", ex -> {
                byte[] data = packBytes;
                ex.getResponseHeaders().add("Content-Type", "application/zip");
                ex.sendResponseHeaders(200, data.length);
                try (OutputStream os = ex.getResponseBody()) { os.write(data); }
            });
            http.createContext("/upload", this::handleUpload);
            http.setExecutor(java.util.concurrent.Executors.newFixedThreadPool(4));
            http.start();
            getLogger().info("Web server listening on port " + getConfig().getInt("web-port", 8123));
        } catch (IOException e) {
            getLogger().severe("Could not start web server: " + e);
        }
    }

    private Map<String, String> query(HttpExchange ex) {
        Map<String, String> m = new HashMap<>();
        String q = ex.getRequestURI().getRawQuery();
        if (q == null) return m;
        for (String part : q.split("&")) {
            int i = part.indexOf('=');
            if (i < 0) continue;
            m.put(URLDecoder.decode(part.substring(0, i), StandardCharsets.UTF_8),
                  URLDecoder.decode(part.substring(i + 1), StandardCharsets.UTF_8));
        }
        return m;
    }

    private boolean tokenValid(String t) {
        Long exp = t == null ? null : tokens.get(t);
        return exp != null && exp > System.currentTimeMillis();
    }

    private void reply(HttpExchange ex, int code, String type, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Content-Type", type + "; charset=utf-8");
        ex.sendResponseHeaders(code, b.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(b); }
    }

    private void handleUpload(HttpExchange ex) throws IOException {
        Map<String, String> q = query(ex);
        String token = q.get("token");
        if (!tokenValid(token)) { reply(ex, 403, "text/plain", "Invalid or expired link. Ask an admin to run /addsound again."); return; }

        if (ex.getRequestMethod().equalsIgnoreCase("GET")) {
            String preset = tokenNames.getOrDefault(token, "");
            reply(ex, 200, "text/html", """
              <!doctype html><meta name=viewport content="width=device-width,initial-scale=1">
              <title>Upload a sound</title>
              <body style="font-family:sans-serif;max-width:480px;margin:40px auto;padding:0 16px">
              <h2>🎵 Upload an MP3</h2>
              <input type=file id=f accept=".mp3,audio/mpeg"><br><br>
              <input id=n placeholder="sound name" value="%s"><br><br>
              <button id=b>Upload</button> <p id=s></p>
              <script>
              const f=document.getElementById('f'),n=document.getElementById('n'),s=document.getElementById('s');
              f.onchange=()=>{ if(!n.value&&f.files[0]) n.value=f.files[0].name.replace(/\\.[^.]+$/,'').toLowerCase().replace(/[^a-z0-9_]+/g,'_'); };
              document.getElementById('b').onclick=async()=>{
                if(!f.files[0]){s.textContent='Pick an mp3 first';return;}
                s.textContent='Uploading & converting...';
                const r=await fetch('/upload?token=%s&name='+encodeURIComponent(n.value),{method:'POST',body:f.files[0]});
                s.textContent=await r.text();
              };
              </script>
              """.formatted(escape(preset), token));
            return;
        }

        // POST: raw mp3 bytes in body
        long max = getConfig().getLong("max-upload-mb", 30) * 1024 * 1024;
        byte[] data = ex.getRequestBody().readNBytes((int) max + 1);
        if (data.length > max) { reply(ex, 413, "text/plain", "File too large."); return; }
        if (data.length < 128) { reply(ex, 400, "text/plain", "Empty file."); return; }

        String name = sanitize(q.getOrDefault("name", ""));
        if (name.isEmpty()) name = "song_" + System.currentTimeMillis() / 1000;
        if (tokens.remove(token) == null) { reply(ex, 403, "text/plain", "Link already used."); return; }
        tokenNames.remove(token);

        Path in = soundsDir.resolve(name + ".upload");
        Path out = soundsDir.resolve(name + ".ogg");
        Files.write(in, data);
        try {
            Process pr = new ProcessBuilder(getConfig().getString("ffmpeg-path", "ffmpeg"), "-y", "-i", in.toString(),
                    "-vn", "-c:a", "libvorbis", "-q:a", "4", "-ar", "44100", out.toString())
                    .redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
            if (!pr.waitFor(180, TimeUnit.SECONDS) || pr.exitValue() != 0 || !Files.exists(out)) {
                pr.destroyForcibly();
                reply(ex, 500, "text/plain", "Conversion failed (is ffmpeg with libvorbis installed on the server?).");
                return;
            }
        } catch (Exception e) {
            reply(ex, 500, "text/plain", "Conversion failed: ffmpeg not found on the server.");
            return;
        } finally {
            Files.deleteIfExists(in);
        }

        rebuildPack();
        final String finalName = name;
        Bukkit.getScheduler().runTask(this, () -> {
            Bukkit.broadcast(Component.text("New sound added: ", NamedTextColor.GREEN)
                    .append(Component.text(finalName, NamedTextColor.YELLOW))
                    .append(Component.text(" — updating resource pack...", NamedTextColor.GREEN)));
            for (Player p : Bukkit.getOnlinePlayers()) sendPack(p);
        });
        reply(ex, 200, "text/plain", "Done! '" + name + "' added. Players are receiving the updated pack. Use /playsong " + name);
    }

    private static String sanitize(String s) { return s.toLowerCase().replaceAll("[^a-z0-9_]+", "_").replaceAll("^_+|_+$", ""); }
    private static String escape(String s) { return s.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;"); }

    // ------------------------------------------------------------------ Commands

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        switch (cmd.getName().toLowerCase()) {
            case "addsound" -> {
                byte[] raw = new byte[18];
                random.nextBytes(raw);
                String token = Base64.getUrlEncoder().withoutPadding().encodeToString(raw);
                tokens.put(token, System.currentTimeMillis() + getConfig().getLong("token-minutes", 10) * 60_000);
                if (args.length > 0) tokenNames.put(token, sanitize(args[0]));
                String url = "http://" + getConfig().getString("public-host") + ":" + getConfig().getInt("public-port")
                        + "/upload?token=" + token;
                sender.sendMessage(Component.text("Click to upload an .mp3 (one use, expires in "
                        + getConfig().getLong("token-minutes", 10) + " min): ", NamedTextColor.GREEN)
                        .append(Component.text(url, NamedTextColor.AQUA).clickEvent(ClickEvent.openUrl(url))));
            }
            case "playsong" -> {
                if (args.length < 1) return false;
                String n = sanitize(args[0]);
                if (!listSongs().contains(n)) { sender.sendMessage(Component.text("No such song. /songs", NamedTextColor.RED)); return true; }
                stopSong();
                currentSong = n;
                for (Player p : Bukkit.getOnlinePlayers())
                    p.playSound(p.getLocation(), NS + ":" + n, SoundCategory.RECORDS, 1f, 1f);
                Bukkit.broadcast(Component.text("♪ Now playing: " + n, NamedTextColor.LIGHT_PURPLE));
            }
            case "stopsong" -> { stopSong(); sender.sendMessage(Component.text("Stopped.", NamedTextColor.YELLOW)); }
            case "songs" -> {
                if (args.length >= 2 && args[0].equalsIgnoreCase("remove")) {
                    String n = sanitize(args[1]);
                    try { Files.deleteIfExists(soundsDir.resolve(n + ".ogg")); } catch (IOException ignored) {}
                    stopSong();
                    rebuildPack();
                    for (Player p : Bukkit.getOnlinePlayers()) sendPack(p);
                    sender.sendMessage(Component.text("Removed " + n, NamedTextColor.YELLOW));
                } else {
                    sender.sendMessage(Component.text("Songs: " + String.join(", ", listSongs()), NamedTextColor.AQUA));
                }
            }
            case "jumpscare" -> {
                if (args.length < 1) return false;
                String song = args.length > 1 ? sanitize(args[1]) : null;
                if (args[0].equalsIgnoreCase("all")) {
                    Bukkit.getOnlinePlayers().forEach(p -> jumpscare(p, song));
                } else {
                    Player t = Bukkit.getPlayerExact(args[0]);
                    if (t == null) { sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED)); return true; }
                    jumpscare(t, song);
                }
            }
        }
        return true;
    }

    private void stopSong() {
        if (currentSong == null) return;
        for (Player p : Bukkit.getOnlinePlayers()) p.stopSound(NS + ":" + currentSong, SoundCategory.RECORDS);
        currentSong = null;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        switch (c.getName().toLowerCase()) {
            case "playsong" -> { if (a.length == 1) out.addAll(listSongs()); }
            case "songs" -> { if (a.length == 1) out.add("remove"); else if (a.length == 2) out.addAll(listSongs()); }
            case "jumpscare" -> {
                if (a.length == 1) { out.add("all"); Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName())); }
                else if (a.length == 2) out.addAll(listSongs());
            }
        }
        String last = a.length == 0 ? "" : a[a.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(last));
        return out;
    }

    // ------------------------------------------------------------------ Jumpscare

    private void jumpscare(Player p, String song) {
        if (!scared.add(p.getUniqueId())) return;

        // Stash the real helmet (also saved in PDC so a crash can't delete it) and put a pumpkin on screen.
        ItemStack real = p.getInventory().getHelmet();
        ItemStack stash = real == null ? new ItemStack(Material.AIR) : real;
        p.getPersistentDataContainer().set(helmetKey, PersistentDataType.BYTE_ARRAY, stash.serializeAsBytes());
        p.getInventory().setHelmet(new ItemStack(Material.CARVED_PUMPKIN));

        p.showTitle(Title.title(Component.text("☠", NamedTextColor.DARK_RED),
                Component.text("BOO!", NamedTextColor.RED),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(1500), Duration.ofMillis(300))));
        p.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 40, 0, false, false, false));

        if (song != null && listSongs().contains(song)) {
            p.playSound(p.getLocation(), NS + ":" + song, SoundCategory.MASTER, 4f, 1f);
        } else {
            p.playSound(p.getLocation(), "entity.ghast.scream", SoundCategory.MASTER, 4f, 0.5f);
            p.playSound(p.getLocation(), "entity.warden.roar", SoundCategory.MASTER, 4f, 1.5f);
            p.playSound(p.getLocation(), "entity.enderman.scream", SoundCategory.MASTER, 4f, 0.5f);
        }

        Bukkit.getScheduler().runTaskLater(this, () -> { if (p.isOnline()) restoreHelmet(p); }, 40L);
    }

    private void restoreHelmet(Player p) {
        byte[] saved = p.getPersistentDataContainer().get(helmetKey, PersistentDataType.BYTE_ARRAY);
        if (saved != null) {
            ItemStack item = ItemStack.deserializeBytes(saved);
            p.getInventory().setHelmet(item.getType() == Material.AIR ? null : item);
            p.getPersistentDataContainer().remove(helmetKey);
        }
        scared.remove(p.getUniqueId());
        p.clearTitle();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { if (scared.contains(e.getPlayer().getUniqueId())) restoreHelmet(e.getPlayer()); }

    @EventHandler
    public void onClick(InventoryClickEvent e) { if (scared.contains(e.getWhoClicked().getUniqueId())) e.setCancelled(true); }

    @EventHandler
    public void onDrag(InventoryDragEvent e) { if (scared.contains(e.getWhoClicked().getUniqueId())) e.setCancelled(true); }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        if (!scared.contains(p.getUniqueId())) return;
        e.getDrops().removeIf(i -> i.getType() == Material.CARVED_PUMPKIN);
        byte[] saved = p.getPersistentDataContainer().get(helmetKey, PersistentDataType.BYTE_ARRAY);
        if (saved != null) {
            ItemStack item = ItemStack.deserializeBytes(saved);
            if (item.getType() != Material.AIR && !e.getKeepInventory()) e.getDrops().add(item);
            p.getPersistentDataContainer().remove(helmetKey);
        }
        scared.remove(p.getUniqueId());
    }
}
